package com.example.project_gemini

data class HushhMenuItem(
    val itemName: String,
    val itemPrice: String,
    val itemStock: String
)
