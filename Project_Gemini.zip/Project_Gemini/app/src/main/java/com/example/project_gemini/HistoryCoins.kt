package com.example.project_gemini

data class HistoryCoins(
    val fieldName: String,
    val fieldValue: String
)
