package com.example.project_gemini

data class CustomCardItem(val imageUrl: String, val parentName: String)

