package com.example.project_gemini

data class QAItem(val question: String, val answer: String)

